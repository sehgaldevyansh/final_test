/* v8 ignore start */

export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
/* v8 ignore stop */
