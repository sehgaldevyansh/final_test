import { describe, it, beforeEach, afterEach } from "vitest";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import FillerSidebar from "./FillerSidebar";
import { vi } from "vitest";
import { Provider } from "react-redux";
import { store } from "../../../store";
import { MemoryRouter } from "react-router-dom";

describe("FillerSidebar component", () => {
  let consoleSpy;

  beforeEach(() => {
    // Mock console.log for spying
    consoleSpy = vi.spyOn(console, "log");
  });

  afterEach(() => {
    // Restore console.log to its original implementation
    consoleSpy.mockRestore();
  });

  it("renders without crashing", () => {
    render(
      <Provider store={store}>
        <MemoryRouter>
          <FillerSidebar />
        </MemoryRouter>
      </Provider>
    );
    // Add assertions to check if the component renders correctly
  });

  it("renders tabs correctly", () => {
    render(
      <Provider store={store}>
        <MemoryRouter>
          <FillerSidebar />
        </MemoryRouter>
      </Provider>
    );
    expect(screen.getByText("Step 1: BLOCK MAPPING")).toBeTruthy();
    expect(screen.getByText("Step 2: GENERAL INFO")).toBeTruthy();
    // Add assertions for other tabs
  });

  it("handles search correctly", () => {
    render(
      <Provider store={store}>
        <MemoryRouter>
          <FillerSidebar />
        </MemoryRouter>
      </Provider>
    );

    // Trigger a search with the input value "sample"
    fireEvent.change(screen.getByPlaceholderText("Enter Here"), {
      target: { value: "sample" },
    });

    // Perform assertions based on the expected behavior after the search
    // For example, check if the component displays the correct search results


    // what to provide here , need data
    // expect(screen.getByText("Found Sample Result")).toBeTruthy();
    // Add more assertions as needed
  });

  it("handles search with empty input correctly", () => {
    render(
      <Provider store={store}>
        <MemoryRouter>
          <FillerSidebar />
        </MemoryRouter>
      </Provider>
    );

    // Trigger a search with an empty input
    fireEvent.change(screen.getByPlaceholderText("Enter Here"), {
      target: { value: "" },
    });

    // Perform assertions based on the expected behavior after the search
    // For example, check if the component displays the full data set
    expect(screen.getByText("Step 1: BLOCK MAPPING")).toBeTruthy();
    // Add more assertions as needed
  });

  // Add more test cases as needed
});
