/* v8 ignore start */

import { loginClient } from './login-client.js';
import Amplify, { Auth } from 'aws-amplify';
export { loginClient, Amplify, Auth };
/* v8 ignore stop */
